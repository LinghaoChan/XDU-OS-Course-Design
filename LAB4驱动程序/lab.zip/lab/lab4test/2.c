#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
int main(){
	char yourmsg[1000] = "18130500001";
	int a= open("/dev/rwbuf", O_RDWR);
	if(a<0){
		printf("打开失败\n");
	}
	int b= write (a, yourmsg, sizeof (yourmsg)+1);
	if(b<0){
		printf("写入失败 \n");
	}
	else
		printf("写 %d bytes.\n", b);
	close(a);
}
