#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
int main(){
	char yourmsg[ 1000];
	int a= open("/dev/rwbuf", O_RDWR);
	if(a<0){
		printf("打开失败 \n");
		return 0;
	}
	int b= read (a, yourmsg, sizeof (yourmsg));
	if(b<0){
		printf("读取失败 \n");
		return 0;
	}
	else if(b==0){
		printf("文件结束\n");
	}else
		printf("%s\n", yourmsg);
	close(a);
}
